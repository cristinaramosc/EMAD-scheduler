from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from backend.repositories.working_timetable_repository import WorkingTimetableRepository, WorkingTimetableSnapshot
    from backend.scheduler_engine.models.activity import Activity
    from backend.scheduler_engine.models.schedule import Schedule
    from backend.repositories.academic_data_repository import AcademicDataRepository
    from backend.scheduler_engine.quarter_utils import group_names, is_valid_quarter_pair, parent_and_quarter as _parent_and_quarter
    from backend.scheduler_engine.teacher_utils import teacher_names
    from backend.scheduler_engine.subject_utils import is_tutoria_subject
    from backend.services.contract_hours import contract_hours
    from backend.services.schedule_pdf_exporter import classify_activity
except ModuleNotFoundError:  # pragma: no cover
    from repositories.working_timetable_repository import WorkingTimetableRepository, WorkingTimetableSnapshot
    from scheduler_engine.models.activity import Activity
    from scheduler_engine.models.schedule import Schedule
    from repositories.academic_data_repository import AcademicDataRepository
    from scheduler_engine.quarter_utils import group_names, is_valid_quarter_pair, parent_and_quarter as _parent_and_quarter
    from scheduler_engine.teacher_utils import teacher_names
    from scheduler_engine.subject_utils import is_tutoria_subject
    from services.contract_hours import contract_hours
    from services.schedule_pdf_exporter import classify_activity

from .serializers import serialize_activity, serialize_conflicts


class LiveScheduleUseCases:
    def __init__(
        self,
        engine: Any,
        working_timetable_repo: WorkingTimetableRepository,
        academic_data_repo: Optional[AcademicDataRepository] = None,
    ) -> None:
        self._engine = engine
        self._working_timetable_repo = working_timetable_repo
        self._academic_data_repo = academic_data_repo

    def load(self, activities: List[Dict[str, Any]]) -> Dict[str, Any]:
        schedule = Schedule()
        for activity in activities:
            schedule.add(Activity(**activity))

        self._engine.load(schedule)
        self._persist_active_schedule(clear_proposal=True)
        return {"status": "ok", "loaded": len(schedule.all())}

    def state(self, conflicts: List[Any] | None = None) -> Dict[str, Any]:
        if conflicts is not None:
            return {
                "activities": [
                    serialize_activity(activity)
                    for activity in self._engine.state.all()
                ],
                "conflicts": serialize_conflicts(conflicts),
                "proposal": None,
                "generation_stats": None,
                "unscheduled_activities": [],
            }

        snapshot = self._working_timetable_repo.load_snapshot()
        if snapshot.current_proposal is not None:
            proposal_payload = dict(snapshot.current_proposal)
            return {
                "activities": proposal_payload.get("activities", []),
                "conflicts": proposal_payload.get("conflicts", []),
                "proposal": proposal_payload,
                "generation_stats": snapshot.generation_stats,
                "unscheduled_activities": snapshot.unscheduled_activities,
            }

        active_conflicts = self._engine.validate()
        return {
            "activities": [
                serialize_activity(activity)
                for activity in self._engine.state.all()
            ],
            "conflicts": serialize_conflicts(active_conflicts),
            "proposal": None,
            "generation_stats": None,
            "unscheduled_activities": [],
        }

    def teacher_schedule(self, teacher_name: str) -> Dict[str, Any]:
        current_state = self.state()
        activities = [
            activity
            for activity in current_state.get("activities", [])
            if teacher_name in teacher_names(activity.get("teacher"))
        ]
        return {
            "teacher": teacher_name,
            "activities": activities,
        }

    def room_schedule(self, room_name: str) -> Dict[str, Any]:
        current_state = self.state()
        activities = [
            activity
            for activity in current_state.get("activities", [])
            if activity.get("room") == room_name
        ]
        return {
            "room": room_name,
            "activities": activities,
        }

    def export_activities(self) -> List[Dict[str, Any]]:
        """Activitats per a l'exportació (Excel/PDF), amb el nom del tutor/a
        de cada grup afegit com a `tutor_name`.

        El nom del tutor no viu a l'activitat, sinó a la fitxa del grup de
        les dades acadèmiques; per això la capçalera "Tutor/a del grup" de
        l'exportació sortia sempre buida. S'afegeix com a `tutor_name` (i no
        com a `tutor`) perquè `is_tutor`/`tutor` són els camps que marquen una
        activitat com a "TUTOR/A" a la graella del PDF.
        """
        activities = self.state().get("activities", [])
        tutor_by_group = self._group_tutors_by_individual_name()
        if not tutor_by_group:
            return activities

        enriched: List[Dict[str, Any]] = []
        for activity in activities:
            tutor = self._resolve_group_tutor(activity.get("group"), tutor_by_group)
            enriched.append({**activity, "tutor_name": tutor} if tutor else activity)
        return enriched

    def export_teachers(self) -> List[Dict[str, Any]]:
        """Professors de les dades acadèmiques (nom i nom de la coordinació),
        per pintar el bloc de coordinació a l'exportació en PDF."""
        if self._academic_data_repo is None:
            return []
        return list(self._academic_data_repo.list_teachers())

    def _group_tutors_by_individual_name(self) -> Dict[str, str]:
        """Mapa {nom de grup individual normalitzat: tutor/a} a partir de les
        dades acadèmiques. Els grups combinats ('GI, GP') compten per a cada
        nom individual."""
        if self._academic_data_repo is None:
            return {}

        tutor_by_group: Dict[str, str] = {}
        for group in self._academic_data_repo.list_groups():
            tutor = str(group.get("tutor") or "").strip()
            if not tutor:
                continue
            for name in group_names(group.get("name")):
                tutor_by_group.setdefault(name, tutor)
        return tutor_by_group

    @staticmethod
    def _resolve_group_tutor(group_field: Any, tutor_by_group: Dict[str, str]) -> str:
        for name in group_names(group_field):
            tutor = tutor_by_group.get(name)
            if tutor:
                return tutor
        return ""

    @staticmethod
    def _conflict_key(conflict: Any) -> tuple:
        return (
            conflict.type,
            conflict.day,
            conflict.start,
            conflict.teacher,
            conflict.room,
            frozenset(conflict.activities or []),
        )

    def _ensure_active_schedule_from_proposal(self) -> None:
        """Si l'horari que es veu a la interfície és encara una proposta
        sense acceptar (`current_proposal` al snapshot), la carrega al
        motor com a horari actiu abans que cap operació manual (moure,
        afegir un descans, etc.) hi actuï.

        Sense això, aquests mètodes treballaven sempre sobre
        `self._engine.state`, que continua buit fins que es fa un
        `accept_proposal` explícit. Com que `state()` ensenya
        `current_proposal` mentre existeixi, la interfície mostrava un
        horari ple mentre el motor no tenia cap activitat carregada:
        exactament el motiu del "cap classe aquell dia per aquest grup"
        en activar un descans sobre una proposta acabada de generar.
        """
        if self._engine.state.all():
            return

        snapshot = self._working_timetable_repo.load_snapshot()
        if snapshot.current_proposal is None:
            return

        proposal_activities = snapshot.current_proposal.get("activities", [])
        schedule = Schedule()
        for activity in proposal_activities:
            schedule.add(Activity(**activity))

        self._engine.load(schedule)
        self._persist_active_schedule(clear_proposal=True)

    def move(self, activity_id: int, day: str, start: str) -> Dict[str, Any]:
        self._ensure_active_schedule_from_proposal()
        activity = next((item for item in self._engine.state.all() if item.id == activity_id), None)
        if activity is None:
            return {
                "ok": False,
                "error": "activity_not_found",
                **self.state(),
            }

        baseline_conflicts = self._engine.validate()
        baseline_keys = {self._conflict_key(conflict) for conflict in baseline_conflicts}

        previous_day = activity.day
        previous_start = activity.start
        activity.day = day
        activity.start = start

        conflicts = self._engine.validate()
        new_conflicts = [
            conflict for conflict in conflicts if self._conflict_key(conflict) not in baseline_keys
        ]

        if new_conflicts:
            activity.day = previous_day
            activity.start = previous_start
            return {
                "ok": False,
                "error": "validation_failed",
                "conflicts": serialize_conflicts(new_conflicts),
                **self.state(conflicts=new_conflicts),
            }

        self._persist_active_schedule(clear_proposal=False)
        return {
            "ok": True,
            **self.state(),
        }

    def move_with_reflow(self, activity_id: int, day: str, start: str) -> Dict[str, Any]:
        """Mou una activitat i reubica en cascada les que bloquegen el destí."""
        self._ensure_active_schedule_from_proposal()
        activities = self._engine.state.all()
        target = next((item for item in activities if item.id == activity_id), None)
        if target is None:
            return {"ok": False, "error": "activity_not_found", **self.state()}

        baseline_keys = {self._conflict_key(conflict) for conflict in self._engine.validate()}
        original_positions = {item.id: (item.day, item.start) for item in activities}
        target.day = day
        target.start = start
        visited = set()

        def conflicts_to_move() -> List[Activity]:
            new_conflicts = [
                conflict for conflict in self._engine.validate()
                if self._conflict_key(conflict) not in baseline_keys
            ]
            ids = {
                activity_id
                for conflict in new_conflicts
                for activity_id in (conflict.activities or [])
                if activity_id != target.id
            }
            return [item for item in activities if item.id in ids and not getattr(item, "fixed", False)]

        def candidate_starts(item: Activity) -> List[tuple[str, str]]:
            hour_names, hour_index = self._half_hour_grid()
            ordered_days = [day] + [value for value in self._DAY_ORDER if value != day]
            target_index = hour_index.get(start, 0)
            preferred_indices = list(range(target_index - 1, -1, -1)) + list(range(target_index + 1, len(hour_names)))
            preferred = [hour_names[index] for index in preferred_indices]
            return [(candidate_day, candidate_start) for candidate_day in ordered_days for candidate_start in preferred]

        def search(depth: int = 0) -> bool:
            blockers = conflicts_to_move()
            if not blockers:
                return not any(
                    self._conflict_key(conflict) not in baseline_keys
                    for conflict in self._engine.validate()
                )
            if depth >= len(activities):
                return False

            blocker = blockers[0]
            original = (blocker.day, blocker.start)
            for candidate_day, candidate_start in candidate_starts(blocker):
                if (candidate_day, candidate_start) == original:
                    continue
                state_key = (blocker.id, candidate_day, candidate_start, depth)
                if state_key in visited:
                    continue
                visited.add(state_key)
                blocker.day = candidate_day
                blocker.start = candidate_start
                if search(depth + 1):
                    return True
                blocker.day, blocker.start = original
            return False

        if not search():
            for item in activities:
                item.day, item.start = original_positions[item.id]
            return {
                "ok": False,
                "error": "reflow_failed",
                "detail": "No s'ha trobat cap reordenació viable per alliberar aquesta franja.",
                **self.state(),
            }

        self._persist_active_schedule(clear_proposal=False)
        return {"ok": True, **self.state()}

    def add_manual_activity(
        self,
        subject: str,
        day: str,
        start: str,
        duration: int = 1,
        teacher: str = "",
        group: str = "",
        room: str = "",
    ) -> Dict[str, Any]:
        """Afegeix una activitat manual a l'horari actiu (p.ex. un descans
        d'estudiants o una hora de coordinació d'un professor) sense passar
        pel generador. Es valida que no introdueixi cap conflicte nou."""
        self._ensure_active_schedule_from_proposal()
        existing_ids = [item.id for item in self._engine.state.all()]
        new_id = (max(existing_ids) + 1) if existing_ids else 1

        new_activity = Activity(
            id=new_id,
            teacher=teacher,
            subject=subject,
            group=group,
            room=room,
            day=day,
            start=start,
            duration=duration,
        )

        baseline_conflicts = self._engine.validate()
        baseline_keys = {self._conflict_key(conflict) for conflict in baseline_conflicts}

        self._engine.state.add(new_activity)

        conflicts = self._engine.validate()
        new_conflicts = [
            conflict for conflict in conflicts if self._conflict_key(conflict) not in baseline_keys
        ]

        if new_conflicts:
            self._engine.state.remove(new_activity)
            return {
                "ok": False,
                "error": "validation_failed",
                "conflicts": serialize_conflicts(new_conflicts),
                **self.state(conflicts=baseline_conflicts),
            }

        self._persist_active_schedule(clear_proposal=False)
        return {
            "ok": True,
            "activity": serialize_activity(new_activity),
            **self.state(),
        }

    def remove_activity(self, activity_id: int) -> Dict[str, Any]:
        self._ensure_active_schedule_from_proposal()
        activity = next((item for item in self._engine.state.all() if item.id == activity_id), None)
        if activity is None:
            return {
                "ok": False,
                "error": "activity_not_found",
                **self.state(),
            }

        self._engine.state.remove(activity)
        self._persist_active_schedule(clear_proposal=False)
        return {
            "ok": True,
            **self.state(),
        }

    _MORNING_BREAK_GROUPS = {"1r apgi", "2n apgi", "pfi", "1r com", "2n com"}
    _AFTERNOON_BREAK_GROUPS = {"comú", "gp", "gi"}
    _DAY_ALIASES = {
        "dilluns": "monday",
        "dimarts": "tuesday",
        "dimecres": "wednesday",
        "dijous": "thursday",
        "divendres": "friday",
        "monday": "monday",
        "tuesday": "tuesday",
        "wednesday": "wednesday",
        "thursday": "thursday",
        "friday": "friday",
    }

    @staticmethod
    def _norm_name(value: str) -> str:
        return (value or "").strip().lower()

    @classmethod
    def _day_key(cls, value: str) -> str:
        normalized = (value or "").strip().lower()
        return cls._DAY_ALIASES.get(normalized, normalized)

    @classmethod
    def _same_day(cls, first: str, second: str) -> bool:
        return cls._day_key(first) == cls._day_key(second)

    @classmethod
    def _slot_matches_day(cls, slot_label: str, day: str) -> bool:
        label = str(slot_label or "")
        slot_day, _, _ = label.partition(" ")
        return bool(slot_day) and cls._same_day(slot_day, day)

    def _get_group_restriction(self, group: str) -> Dict[str, Any]:
        if self._academic_data_repo is None:
            return {"group": group}

        target = self._norm_name(group)
        for restriction in self._academic_data_repo.list_group_restrictions():
            if self._norm_name(restriction.get("group", "")) == target:
                return dict(restriction)
        return {"group": group}

    def _save_group_restriction(self, restriction: Dict[str, Any]) -> None:
        if self._academic_data_repo is None:
            return
        self._academic_data_repo.upsert_group_restriction(restriction)

    def auto_place_breaks(self) -> Dict[str, Any]:
        """Afegeix automàticament un descans de 30 min a cada dia amb classes
        de cada grup, si encara no en té cap. Pensat per cridar-se just
        després de generar/acceptar un horari nou. No sobreescriu cap
        descans ja actiu i, si un dia concret no té cap forat lliure dins la
        finestra permesa, simplement no s'hi afegeix (sense avisar d'error:
        es limita a informar-ho al resultat)."""
        self._ensure_active_schedule_from_proposal()

        groups_and_days: set = set()
        for activity in self._engine.state.all():
            group = getattr(activity, "group", None)
            day = getattr(activity, "day", None)
            if group and day:
                groups_and_days.add((group, day))

        added: List[Dict[str, str]] = []
        skipped: List[Dict[str, str]] = []

        for group, day in sorted(groups_and_days):
            restriction = self._get_group_restriction(group)
            break_days = restriction.get("break_days") or []
            if any(self._same_day(stored_day, day) for stored_day in break_days):
                continue  # ja te descans aquell dia, no el toquem

            result = self.toggle_group_break(group, day)
            if result.get("ok") and result.get("active"):
                added.append({"group": group, "day": day})
            else:
                skipped.append({"group": group, "day": day, "reason": result.get("detail") or result.get("error") or ""})

        return {"ok": True, "added": added, "skipped": skipped, **self.state()}

    def toggle_group_break(self, group: str, day: str) -> Dict[str, Any]:
        """Activa/desactiva un descans de 30 min com a buit de calendari
        (restricció flexible), sense crear cap activitat "Descans".

        En activar-lo, obre un forat real desplaçant la cadena necessària
        d'activitats; en desactivar-lo, compacta les classes posteriors.
        El dia actiu i la franja s'emmagatzemen a la restricció del grup
        (`break_days` i `break_slots`)."""
        self._ensure_active_schedule_from_proposal()
        hour_names, hour_index = self._half_hour_grid()
        target_group = self._norm_name(group)

        restriction = self._get_group_restriction(group)
        break_days = list(restriction.get("break_days") or [])
        break_slots = list(restriction.get("break_slots") or [])

        active_slot_label = next((slot for slot in break_slots if self._slot_matches_day(str(slot), day)), None)
        is_active = any(self._same_day(stored_day, day) for stored_day in break_days)

        if is_active:
            removed_idx = None
            if active_slot_label:
                _, _, start_label = str(active_slot_label).partition(" ")
                removed_idx = hour_index.get(start_label, None)

            # Neteja de compatibilitat: si encara hi havia un "Descans"
            # antic al calendari, s'elimina en desactivar.
            legacy_breaks = [
                item for item in self._engine.state.all()
                if self._norm_name(item.group) == target_group
                and item.day == day
                and (item.subject or "").strip().lower() == "descans"
            ]
            for legacy in legacy_breaks:
                self._engine.state.remove(legacy)
                if removed_idx is None:
                    removed_idx = hour_index.get(legacy.start, None)

            break_days = [value for value in break_days if not self._same_day(value, day)]
            break_slots = [slot for slot in break_slots if not self._slot_matches_day(str(slot), day)]

            if removed_idx is not None:
                # Només compactem si realment hi havia un forat físic obert
                # en aquesta franja (mode "gap"). Si la franja estava
                # ocupada per una classe (mode "marker_only"), no movem res.
                has_activity_at_removed_idx = any(
                    self._norm_name(item.group) == target_group
                    and item.day == day
                    and (item.subject or "").strip().lower() != "descans"
                    and hour_index.get(item.start, -1) == removed_idx
                    for item in self._engine.state.all()
                )
                if has_activity_at_removed_idx:
                    removed_idx = None

            if removed_idx is not None:
                later_items = sorted(
                    (
                        item
                        for item in self._engine.state.all()
                        if self._norm_name(item.group) == target_group
                        and item.day == day
                        and hour_index.get(item.start, -1) > removed_idx
                    ),
                    key=lambda item: hour_index.get(item.start, -1),
                )
                for item in later_items:
                    idx = hour_index.get(item.start, -1)
                    if idx <= 0:
                        continue
                    result = self.move(item.id, item.day, hour_names[idx - 1])
                    if not result.get("ok"):
                        break

            restriction["group"] = restriction.get("group") or group
            restriction["break_days"] = break_days
            restriction["break_slots"] = break_slots
            self._save_group_restriction(restriction)
            self._persist_active_schedule(clear_proposal=False)
            return {"ok": True, "active": False, "break_days": break_days, **self.state()}

        day_activities = [
            item for item in self._engine.state.all()
            if self._norm_name(item.group) == target_group and self._same_day(item.day, day)
            and (item.subject or "").strip().lower() != "descans"
        ]
        if not day_activities:
            known_groups = sorted(
                {
                    item.group
                    for item in self._engine.state.all()
                    if self._same_day(item.day, day) and item.group
                }
            )
            return {
                "ok": False,
                "error": "no_free_slot",
                "detail": f"cap classe aquell dia per aquest grup (grups amb classe {day}: {known_groups})",
                "active": False,
                **self.state(),
            }

        exceptions = set()
        if self._academic_data_repo is not None:
            group_restriction_entry = next(
                (
                    r for r in self._academic_data_repo.list_group_restrictions()
                    if self._norm_name(r.get("group")) == target_group
                ),
                None,
            )
            if group_restriction_entry:
                exceptions = set(group_restriction_entry.get("exception_slots") or [])

        span_activities = [item for item in day_activities if f"{item.day} {item.start}" not in exceptions] or day_activities

        start_indices = [hour_index.get(item.start, -1) for item in span_activities]
        end_indices = [hour_index.get(item.start, -1) + item.duration for item in span_activities]
        if -1 in start_indices:
            bad_starts = [item.start for item in span_activities if hour_index.get(item.start, -1) == -1]
            return {"ok": False, "error": "no_free_slot", "detail": f"hora no reconeguda: {bad_starts}", "active": False, **self.state()}

        day_start_idx = min(start_indices)
        day_end_idx = max(end_indices)

        window_start_idx = day_start_idx + 2  # 1h després de començar
        window_end_idx = day_end_idx - 3  # 1h30 abans d'acabar

        midday_idx = hour_index.get("14:00")
        if midday_idx is not None:
            if target_group in self._MORNING_BREAK_GROUPS:
                window_end_idx = min(window_end_idx, midday_idx - 1)
            elif target_group in self._AFTERNOON_BREAK_GROUPS:
                window_start_idx = max(window_start_idx, midday_idx)

        if window_start_idx > window_end_idx or window_start_idx >= len(hour_names):
            return {
                "ok": False,
                "error": "no_free_slot",
                "detail": (
                    f"classes de {hour_names[day_start_idx]} a {hour_names[day_end_idx - 1] if day_end_idx - 1 < len(hour_names) else '?'} "
                    f"({(day_end_idx - day_start_idx) * 0.5}h seguides): no hi cap un descans dins la finestra permesa "
                    "(1h després de començar, 1h30 abans d'acabar)"
                ),
                "active": False,
                **self.state(),
            }

        insertion_idx = window_start_idx

        # Si el punt d'inserció cau enmig d'una activitat que ja està en
        # curs (comença abans però la seva durada arriba fins aquí; és el
        # cas típic d'una parella 1Q/2Q alineada a la mateixa franja),
        # endarrereix el punt d'inserció fins que aquesta activitat acabi,
        # perquè el descans mai es col·loqui a sobre d'una classe que ja
        # hi és. Es repeteix fins que no hi hagi cap solapament, per si
        # l'endarreriment fa caure el punt dins d'una altra activitat.
        overlap_found = True
        while overlap_found:
            overlap_found = False
            for item in day_activities:
                item_idx = hour_index.get(item.start, -1)
                if item_idx == -1:
                    continue
                item_end_idx = item_idx + item.duration
                if item_idx < insertion_idx < item_end_idx:
                    insertion_idx = item_end_idx
                    overlap_found = True

        if insertion_idx > window_end_idx or insertion_idx >= len(hour_names):
            return {
                "ok": False,
                "error": "no_free_slot",
                "detail": "no hi ha cap forat lliure dins la finestra permesa per posar-hi el descans aquell dia",
                "active": False,
                **self.state(),
            }

        chosen_start = hour_names[insertion_idx]

        # Desplaça 30 min més tard NOMÉS la cadena d'activitats contigües que
        # comencin exactament al punt d'inserció (o que quedin ocupant-lo en
        # cascada). Si aquella franja ja és un forat lliure de manera natural
        # (per exemple perquè aquell dia hi ha una classe més curta que la
        # resta i deixa un buit abans del descans), no cal desplaçar res:
        # el descans s'hi col·loca directament sense tocar la resta del dia.
        occupied_slots = set()
        items_at_start_idx: Dict[int, List[Any]] = {}
        for item in day_activities:
            idx = hour_index.get(item.start, -1)
            if idx == -1:
                continue
            items_at_start_idx.setdefault(idx, []).append(item)
            duration = max(int(getattr(item, "duration", 1) or 1), 1)
            for offset in range(duration):
                occupied_slots.add(idx + offset)

        to_shift = []
        cursor = insertion_idx
        while cursor in occupied_slots:
            items = items_at_start_idx.get(cursor, [])
            if not items:
                break  # franja ocupada per la cua d'una activitat que ja comença abans
            to_shift.extend(items)
            cursor = max(
                hour_index.get(item.start, -1) + max(int(getattr(item, "duration", 1) or 1), 1)
                for item in items
            )

        to_shift.sort(key=lambda item: hour_index.get(item.start, -1), reverse=True)
        original_positions = {item.id: (item.day, item.start) for item in to_shift}
        baseline_conflicts = self._engine.validate()
        baseline_keys = {self._conflict_key(conflict) for conflict in baseline_conflicts}
        for item in to_shift:
            idx = hour_index.get(item.start, -1)
            new_idx = idx + 1
            if new_idx + item.duration > len(hour_names):
                return {
                    "ok": False,
                    "error": "no_free_slot",
                    "detail": "no es pot obrir el forat: desplaçaria una classe fora de l'horari del dia",
                    "active": False,
                    **self.state(),
                }

        # Mou tota la cadena en memòria i valida el resultat final. Fer-ho com
        # una sola operació evita que el segon desplaçament sigui rebutjat pel
        # primer, o que un error deixi la cadena parcialment persistida.
        for item in to_shift:
            idx = hour_index.get(item.start, -1)
            item.start = hour_names[idx + 1]

        new_conflicts = [
            conflict for conflict in self._engine.validate()
            if self._conflict_key(conflict) not in baseline_keys
        ]
        if new_conflicts:
            for item in to_shift:
                item.day, item.start = original_positions[item.id]
            return {
                "ok": False,
                "error": "no_free_slot",
                "detail": "no es pot obrir el forat: no s'ha pogut desplaçar tota la cadena",
                "active": False,
                **self.state(conflicts=new_conflicts),
            }

        chosen_end_idx = insertion_idx + 1
        overlaps_break = any(
            self._norm_name(item.group) == target_group
            and self._same_day(item.day, day)
            and (item.subject or "").strip().lower() != "descans"
            and hour_index.get(item.start, -1) < chosen_end_idx
            and hour_index.get(item.start, -1) + max(int(getattr(item, "duration", 1) or 1), 1) > insertion_idx
            for item in self._engine.state.all()
        )
        if overlaps_break:
            for item in to_shift:
                if item.id in original_positions:
                    item.start = original_positions[item.id]
            return {
                "ok": False,
                "error": "no_free_slot",
                "detail": "no es pot obrir el forat sense compartir-lo amb una assignatura",
                "active": False,
                **self.state(),
            }

        restriction["group"] = restriction.get("group") or group
        restriction["break_days"] = sorted({*break_days, day})
        break_slots = [slot for slot in break_slots if not self._slot_matches_day(str(slot), day)]
        break_slots.append(f"{day} {chosen_start}")
        restriction["break_slots"] = break_slots
        self._save_group_restriction(restriction)

        self._persist_active_schedule(clear_proposal=False)
        return {"ok": True, "active": True, "break_days": restriction["break_days"], **self.state()}

    _LUNCH_WINDOW_STARTS = ["12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00"]
    _LUNCH_MORNING_BEFORE = "12:00"
    _LUNCH_AFTERNOON_FROM = "16:00"

    def assign_teacher_lunch_breaks(self) -> Dict[str, Any]:
        """Afegeix una hora de dinar (entre les 12h i les 16h) a cada
        professor que tingui classe abans de les 12h i també a partir de
        les 16h el mateix dia, si encara no en té cap assignada."""
        self._ensure_active_schedule_from_proposal()
        hour_names = []
        hour = 8 * 60
        while hour <= 21 * 60:
            hour_names.append(f"{hour // 60}:{hour % 60:02d}")
            hour += 30
        hour_index = {name: index for index, name in enumerate(hour_names)}
        morning_limit = hour_index.get(self._LUNCH_MORNING_BEFORE)
        afternoon_start = hour_index.get(self._LUNCH_AFTERNOON_FROM)
        if morning_limit is None or afternoon_start is None:
            return {"ok": False, "error": "invalid_time_window", **self.state()}

        activities = list(self._engine.state.all())
        by_teacher_day: Dict[tuple, List[Activity]] = {}
        for activity in activities:
            if not activity.teacher or not activity.day or activity.start not in hour_index:
                continue
            by_teacher_day.setdefault((activity.teacher, activity.day), []).append(activity)

        added = []
        skipped_no_slot = []
        for (teacher, day), day_activities in by_teacher_day.items():
            has_morning = any(hour_index[a.start] < morning_limit for a in day_activities)
            has_afternoon = any(hour_index[a.start] >= afternoon_start for a in day_activities)
            already_has_lunch = any((a.subject or "").strip().lower() == "dinar" for a in day_activities)
            if not (has_morning and has_afternoon) or already_has_lunch:
                continue

            occupied_starts = {a.start for a in day_activities}
            chosen_start = None
            for start in self._LUNCH_WINDOW_STARTS:
                start_idx = hour_index[start]
                second_half = hour_names[start_idx + 1] if start_idx + 1 < len(hour_names) else None
                if start in occupied_starts:
                    continue
                if second_half and second_half in occupied_starts:
                    continue
                chosen_start = start
                break

            if chosen_start is None:
                skipped_no_slot.append({"teacher": teacher, "day": day})
                continue

            result = self.add_manual_activity(
                subject="Dinar",
                day=day,
                start=chosen_start,
                duration=2,
                teacher=teacher,
            )
            if result.get("ok"):
                added.append({"teacher": teacher, "day": day, "start": chosen_start})

        return {
            "ok": True,
            "added": added,
            "skipped_no_slot": skipped_no_slot,
            **self.state(),
        }

    # ---------------------------------------------------------------
    # Compactació 1Q/2Q: unir en una mateixa franja les assignatures
    # "bessones" d'un mateix grup pare (a la interfície es pinten 1Q a
    # l'esquerra i 2Q a la dreta quan comparteixen casella).
    # ---------------------------------------------------------------

    @staticmethod
    def _match_quarter_pairs(ones: List[Activity], twos: List[Activity]) -> List[tuple]:
        """Aparella cada activitat marcada 1Q amb una de 2Q del mateix grup
        pare (mai 1Q amb 1Q ni 2Q amb 2Q). Quan un grup té més d'una parella
        possible, prioritza les combinacions on coincideix el professor; la
        resta s'aparellen en l'ordre en què apareixen com a darrer recurs,
        perquè cap activitat 1Q o 2Q es quedi sense parella si n'hi ha una
        de disponible. L'ordre retornat és sempre (activitat_1Q, activitat_2Q)."""
        remaining_ones = list(ones)
        remaining_twos = list(twos)
        pairs: List[tuple] = []

        for one in list(remaining_ones):
            match = next(
                (two for two in remaining_twos if (one.teacher or "").strip() and one.teacher == two.teacher),
                None,
            )
            if match is not None:
                pairs.append((one, match))
                remaining_ones.remove(one)
                remaining_twos.remove(match)

        for one, two in zip(remaining_ones, remaining_twos):
            pairs.append((one, two))

        return pairs

    def align_quarter_pairs(self) -> Dict[str, Any]:
        """Compacta a la mateixa franja horària (mateix dia i hora) les
        assignatures 1Q i 2Q d'un mateix grup pare, prioritzant aparellar
        les que comparteixen professor. Reutilitza `move()` per validar que
        el desplaçament no introdueixi cap conflicte nou; si moure la 2Q
        sobre la 1Q falla, prova al revés abans de descartar la parella."""
        self._ensure_active_schedule_from_proposal()

        by_parent: Dict[str, Dict[str, List[Activity]]] = {}
        for activity in self._engine.state.all():
            parent, quarter_marker = _parent_and_quarter(activity.group, activity.subject)
            if quarter_marker is None:
                continue
            # Cada activitat compta per a CADA grup individual que hi
            # assisteix, no nomes pel text exacte del grup pare: una
            # activitat de 'GI, GP' ha de poder-se aparellar tant amb una
            # activitat nomes de GI com nomes de GP.
            for individual_name in group_names(parent) or (parent,):
                by_parent.setdefault(individual_name, {"1q": [], "2q": []})[quarter_marker].append(activity)

        pairs_to_align: List[tuple] = []
        seen_pairs: set = set()
        for buckets in by_parent.values():
            for pair in self._match_quarter_pairs(buckets["1q"], buckets["2q"]):
                pair_key = frozenset({id(pair[0]), id(pair[1])})
                if pair_key in seen_pairs:
                    continue
                seen_pairs.add(pair_key)
                pairs_to_align.append(pair)

        aligned: List[Dict[str, Any]] = []
        skipped: List[Dict[str, Any]] = []

        for act_a, act_b in pairs_to_align:
            if act_a.day == act_b.day and act_a.start == act_b.start:
                continue  # ja comparteixen casella

            if not is_valid_quarter_pair(act_a.group, act_a.subject, act_b.group, act_b.subject):
                skipped.append({"subject_1q": act_a.subject, "subject_2q": act_b.subject, "reason": "invalid_pair"})
                continue

            target_day, target_start = act_a.day, act_a.start
            result = self.move(act_b.id, target_day, target_start)
            if not result.get("ok"):
                target_day, target_start = act_b.day, act_b.start
                result = self.move(act_a.id, target_day, target_start)

            if result.get("ok"):
                aligned.append(
                    {
                        "group": act_a.group,
                        "subject_1q": act_a.subject,
                        "subject_2q": act_b.subject,
                        "teacher_1q": act_a.teacher,
                        "teacher_2q": act_b.teacher,
                        "day": target_day,
                        "start": target_start,
                    }
                )
            else:
                skipped.append({"subject_1q": act_a.subject, "subject_2q": act_b.subject, "reason": "conflict"})

        return {
            "ok": True,
            "aligned": aligned,
            "skipped": skipped,
            **self.state(),
        }

    # ---------------------------------------------------------------
    # Reunió/Coordinació fixes (dimecres) + repartiment automàtic de les
    # hores de centre i coordinació restants de cada professor.
    # ---------------------------------------------------------------

    _DAY_ORDER = ["Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres"]
    _FIXED_MEETING_DAY = "Dimecres"
    _FIXED_MEETING_BLOCKS = [("Reunió", "14:00"), ("Coordinació", "15:00")]  # 1h cadascun
    _MAX_DAILY_BLOCKS = 24  # 12h * 2 blocs de 30 min

    @staticmethod
    def _half_hour_grid() -> tuple[List[str], Dict[str, int]]:
        hour_names = []
        hour = 8 * 60
        while hour <= 21 * 60:
            hour_names.append(f"{hour // 60}:{hour % 60:02d}")
            hour += 30
        return hour_names, {name: index for index, name in enumerate(hour_names)}

    @staticmethod
    def _to_hours(value: Any) -> float:
        if value in (None, ""):
            return 0.0
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    def _place_extra_hours_for_teacher(
        self,
        teacher: str,
        subject: str,
        blocks_needed: int,
        hour_names: List[str],
        hour_index: Dict[str, int],
        group: str = "",
    ) -> tuple:
        """Col·loca `blocks_needed` blocs de 30 min per a `teacher` com a
        `subject`, enganxats abans o després de les classes que ja tingui
        cada dia, sense superar les 12h/dia (_MAX_DAILY_BLOCKS) si és
        evitable. Si no hi caben enlloc, els assigna igualment al final
        del darrer dia amb classes i ho marca com a conflicte."""
        added: List[Dict[str, Any]] = []
        exceeded: List[Dict[str, Any]] = []

        teacher_days = [
            day for day in self._DAY_ORDER
            if any(teacher in teacher_names(a.teacher) and a.day == day for a in self._engine.state.all())
        ]

        for day in teacher_days:
            if blocks_needed <= 0:
                break

            day_activities = sorted(
                (a for a in self._engine.state.all() if teacher in teacher_names(a.teacher) and a.day == day),
                key=lambda a: hour_index.get(a.start, -1),
            )
            if not day_activities:
                continue

            used_blocks = sum(a.duration for a in day_activities)
            free_blocks = self._MAX_DAILY_BLOCKS - used_blocks
            if free_blocks <= 0:
                continue
            chunk = min(blocks_needed, free_blocks)

            placed = False
            last = day_activities[-1]
            last_end_idx = hour_index.get(last.start, -1) + last.duration
            if 0 <= last_end_idx and last_end_idx + chunk <= len(hour_names):
                start_name = hour_names[last_end_idx]
                result = self.add_manual_activity(subject=subject, day=day, start=start_name, duration=chunk, teacher=teacher, group=group)
                if result.get("ok"):
                    added.append({"teacher": teacher, "day": day, "start": start_name, "duration": chunk, "subject": subject, "group": group})
                    blocks_needed -= chunk
                    placed = True

            if not placed:
                first = day_activities[0]
                first_start_idx = hour_index.get(first.start, -1)
                place_blocks = min(chunk, first_start_idx) if first_start_idx > 0 else 0
                if place_blocks > 0:
                    start_idx = first_start_idx - place_blocks
                    start_name = hour_names[start_idx]
                    result = self.add_manual_activity(subject=subject, day=day, start=start_name, duration=place_blocks, teacher=teacher, group=group)
                    if result.get("ok"):
                        added.append({"teacher": teacher, "day": day, "start": start_name, "duration": place_blocks, "subject": subject, "group": group})
                        blocks_needed -= place_blocks

        if blocks_needed > 0 and teacher_days:
            day = teacher_days[-1]
            day_activities = sorted(
                (a for a in self._engine.state.all() if teacher in teacher_names(a.teacher) and a.day == day),
                key=lambda a: hour_index.get(a.start, -1),
            )
            if day_activities:
                last = day_activities[-1]
                last_end_idx = hour_index.get(last.start, -1) + last.duration
                if 0 <= last_end_idx < len(hour_names):
                    place_blocks = min(blocks_needed, len(hour_names) - last_end_idx)
                    if place_blocks > 0:
                        start_name = hour_names[last_end_idx]
                        result = self.add_manual_activity(subject=subject, day=day, start=start_name, duration=place_blocks, teacher=teacher, group=group)
                        if result.get("ok"):
                            added.append({"teacher": teacher, "day": day, "start": start_name, "duration": place_blocks, "subject": subject, "group": group})
                            blocks_needed -= place_blocks
                            exceeded.append({"teacher": teacher, "day": day, "subject": subject, "extra_blocks": place_blocks})

        return blocks_needed, added, exceeded

    def assign_center_and_coordination_hours(self) -> Dict[str, Any]:
        """Per a cada professor: si té el bloc fix de dimecres (Reunió
        14-15h + Coordinació 15-16h) activat, l'assigna i en resta 1h de
        les hores de centre i 1h de les de coordinació. Reparteix la resta
        de les hores de centre/coordinació enganxades a les classes que ja
        tingui, sense superar les 12h/dia si és evitable; si no hi caben
        enlloc, les assigna igualment i ho marca com a conflicte."""
        if self._academic_data_repo is None:
            return {"ok": False, "error": "academic_data_repo_unavailable", **self.state()}

        self._ensure_active_schedule_from_proposal()
        hour_names, hour_index = self._half_hour_grid()
        restrictions = {r.get("teacher"): r for r in self._academic_data_repo.list_teacher_restrictions()}

        tutored_groups: Dict[str, List[str]] = {}
        for group in self._academic_data_repo.list_groups():
            tutor = str(group.get("tutor") or "").strip()
            group_name = str(group.get("name") or "").strip()
            if tutor and group_name:
                tutored_groups.setdefault(tutor.casefold(), []).append(group_name)

        added_meetings: List[Dict[str, Any]] = []
        added_hours: List[Dict[str, Any]] = []
        daily_hours_exceeded: List[Dict[str, Any]] = []
        skipped_no_slot: List[Dict[str, Any]] = []

        for teacher in self._academic_data_repo.list_teachers():
            name = teacher.get("name")
            if not name:
                continue
            # `list_teachers()` filtra pel flag intern del repositori (sempre
            # actiu en crear), no pel camp `active` de la fitxa. Un professor
            # marcat com a inactiu (o files amb noms combinats com "Eli,
            # Cristina", que no són un professor real) no ha de rebre hores
            # de centre ni el bloc fix de dimecres; si no, xocaria amb el
            # bloc del professor real al mateix dimecres 14-15h.
            if not teacher.get("active", True):
                continue

            restriction = restrictions.get(name, {})
            weekly_meeting_active = restriction.get("weekly_meeting_active", True)
            weekly_coordination_active = restriction.get("weekly_coordination_active", True)
            block_active = {"Reunió": weekly_meeting_active, "Coordinació": weekly_coordination_active}

            # Si el professor té un % de jornada, les hores de centre són les
            # del contracte (7,5 h al 100 %, vegeu `contract_hours`) i inclouen
            # la reunió i la coordinació fixes de dimecres; si no, es fa servir
            # el camp manual `center_hours` com sempre.
            contract = contract_hours(teacher.get("dedication_pct"))
            remaining_center = contract["centre"] if contract else self._to_hours(teacher.get("center_hours"))
            remaining_coordination = self._to_hours(teacher.get("coordination_hours"))

            existing_day_activities = [
                a for a in self._engine.state.all()
                if name in teacher_names(a.teacher) and a.day == self._FIXED_MEETING_DAY
            ]
            for subject, start in self._FIXED_MEETING_BLOCKS:
                if not block_active[subject]:
                    continue
                already_present = any(
                    (a.subject or "").strip().lower() == subject.lower() and a.start == start
                    for a in existing_day_activities
                )
                if not already_present:
                    result = self.add_manual_activity(
                        subject=subject, day=self._FIXED_MEETING_DAY, start=start, duration=2, teacher=name,
                    )
                    if result.get("ok"):
                        added_meetings.append({"teacher": name, "subject": subject})
                    else:
                        skipped_no_slot.append({"teacher": name, "subject": subject, "reason": "conflict"})
                        continue
                if subject == "Reunió":
                    remaining_center = max(0.0, remaining_center - 1.0)
                else:
                    remaining_coordination = max(0.0, remaining_coordination - 1.0)
                    if contract:
                        remaining_center = max(0.0, remaining_center - 1.0)

            # Tutoria: el tutor/a de cada grup en té 1 h lectiva setmanal (no
            # lectiva per als alumnes: no ocupa franja del grup). Només s'hi
            # assigna si no consta ja cap Tutoria d'aquest grup.
            for tutored_group in tutored_groups.get(name.casefold(), []):
                if self._group_has_tutoria(tutored_group):
                    continue
                pending, added, exceeded = self._place_extra_hours_for_teacher(
                    teacher=name, subject="Tutoria", blocks_needed=self._TUTORIA_BLOCKS,
                    hour_names=hour_names, hour_index=hour_index, group=tutored_group,
                )
                added_hours.extend(added)
                daily_hours_exceeded.extend(exceeded)
                if pending > 0:
                    skipped_no_slot.append({"teacher": name, "subject": "Tutoria", "group": tutored_group, "reason": "no_existing_day", "pending_blocks": pending})

            for subject, remaining in (("Hores de centre", remaining_center), ("Coordinació", remaining_coordination)):
                blocks_needed = round(remaining * 2)
                if blocks_needed <= 0:
                    continue
                pending, added, exceeded = self._place_extra_hours_for_teacher(
                    teacher=name, subject=subject, blocks_needed=blocks_needed,
                    hour_names=hour_names, hour_index=hour_index,
                )
                added_hours.extend(added)
                daily_hours_exceeded.extend(exceeded)
                if pending > 0:
                    skipped_no_slot.append({"teacher": name, "subject": subject, "reason": "no_existing_day", "pending_blocks": pending})

        return {
            "ok": True,
            "added_meetings": added_meetings,
            "added_hours": added_hours,
            "daily_hours_exceeded": daily_hours_exceeded,
            "skipped_no_slot": skipped_no_slot,
            **self.state(),
        }


    #: Durada de la Tutoria automàtica: 1 h (2 blocs de 30 min).
    _TUTORIA_BLOCKS = 2

    def _group_has_tutoria(self, group_name: str) -> bool:
        """True si l'horari actiu ja té una Tutoria per a aquest grup."""
        target = set(group_names(group_name))
        return any(
            is_tutoria_subject(a.subject) and target.intersection(group_names(a.group))
            for a in self._engine.state.all()
        )

    def teacher_hours_summary(self) -> List[Dict[str, Any]]:
        """Per a cada professor amb % de jornada: hores de contracte (lectives,
        centre, preparació) i hores que ja té a l'horari actiu, amb la
        diferència, perquè es vegi si falten o sobren hores lectives o de
        centre. Les lectives sumen classes, tutories i coordinacions."""
        if self._academic_data_repo is None:
            return []
        scheduled: Dict[str, Dict[str, float]] = {}
        for activity in self._engine.state.all():
            row = {
                "subject": activity.subject, "day": activity.day, "start": activity.start,
                "group": activity.group, "teacher": activity.teacher, "duration": activity.duration,
            }
            kind = classify_activity(row)
            if kind is None:
                continue
            hours = (activity.duration or 0) / 2
            bucket = {"subject": "classes", "tutoria": "tutoria", "coordination": "coordination"}.get(kind, "centre")
            for name in teacher_names(activity.teacher):
                totals = scheduled.setdefault(name, {"classes": 0.0, "tutoria": 0.0, "coordination": 0.0, "centre": 0.0})
                totals[bucket] += hours
        summary = []
        for teacher in self._academic_data_repo.list_teachers():
            name = teacher.get("name")
            contract = contract_hours(teacher.get("dedication_pct"))
            if not name or not teacher.get("active", True) or contract is None:
                continue
            done = scheduled.get(name, {"classes": 0.0, "tutoria": 0.0, "coordination": 0.0, "centre": 0.0})
            lective_done = done["classes"] + done["tutoria"] + done["coordination"]
            summary.append({
                "teacher": name,
                "contract": contract,
                "scheduled": {**done, "lective": lective_done},
                "missing_lective": round(contract["lective"] - lective_done, 2),
                "missing_centre": round(contract["centre"] - done["centre"], 2),
            })
        return summary

    def _persist_active_schedule(self, clear_proposal: bool) -> None:
        previous = self._working_timetable_repo.load_snapshot()
        self._working_timetable_repo.save_snapshot(
            WorkingTimetableSnapshot(
                active_schedule=[serialize_activity(activity) for activity in self._engine.state.all()],
                current_proposal=None if clear_proposal else previous.current_proposal,
                generation_stats=None if clear_proposal else previous.generation_stats,
                unscheduled_activities=[] if clear_proposal else previous.unscheduled_activities,
                metadata={**previous.metadata, "last_source": "active_schedule"},
            )
        )
