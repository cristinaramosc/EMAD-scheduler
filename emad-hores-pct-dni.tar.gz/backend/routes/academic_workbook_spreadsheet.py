"""Exporta i importa un únic full de càlcul (.xlsx) amb totes les dades
acadèmiques (professors, grups, assignatures i aules), com a alternativa
a treballar directament amb els llibres Excel acadèmics.

Unitat de temps: sempre en HORES, en format decimal (p.ex. 1,5 = una hora
i mitja). El mínim per sessió és 1 hora.
"""

from __future__ import annotations

from io import BytesIO
from typing import Any, Dict, List

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

try:
    from backend.repositories.academic_data_repository import AcademicDataRepository
    from backend.services.contract_hours import parse_dedication_pct
except ModuleNotFoundError:  # pragma: no cover
    from repositories.academic_data_repository import AcademicDataRepository
    from services.contract_hours import parse_dedication_pct

try:
    from backend.dependencies import get_academic_data_repo
except ModuleNotFoundError:  # pragma: no cover
    from dependencies import get_academic_data_repo

from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse


router = APIRouter(prefix="/academic-data", tags=["Academic Workbook Spreadsheet"])


HEADER_FILL = PatternFill(start_color="263447", end_color="263447", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)
NOTE_FONT = Font(italic=True, color="667085")

TEACHER_COLUMNS = [
    ("name", "Nom"),
    ("active", "Actiu (Sí/No)"),
    ("dedication_pct", "Dedicació (% de jornada)"),
    ("dni", "DNI"),
    ("center_hours", "Hores de centre"),
    ("coordination_name", "Coordinació (nom)"),
    ("coordination_hours", "Coordinació (hores)"),
    ("no_gaps", "Sense buits (Sí/No)"),
    ("max_hours_per_day", "Màx. hores/dia"),
    ("max_consecutive_hours", "Màx. hores consecutives"),
    ("max_days", "Màxim de dies de classe per setmana (opcional)"),
    ("unavailable_slots", "Franges no disponibles (franges separades per comes)"),
    ("tutor_of", "Tutor/a de (grups, informatiu: es canvia a Grups)"),
]

GROUP_COLUMNS = [
    ("name", "Nom del grup"),
    ("active", "Actiu (Sí/No)"),
    ("tutor", "Tutor"),
    ("is_split", "Desdoblat (Sí/No)"),
    ("no_gaps", "Sense buits (Sí/No)"),
    ("max_hours_per_day", "Màx. hores/dia"),
    ("max_consecutive_hours", "Màx. hores consecutives"),
    ("max_days", "Màxim de dies de classe per setmana (opcional)"),
    ("minimum_daily_hours", "Mínim d'hores diàries"),
    ("preferred_availability", "Disponibilitat preferida (franges separades per comes)"),
    ("unavailable_slots", "Franges no disponibles (franges separades per comes)"),
]

SUBJECT_COLUMNS = [
    ("subject", "Nom de l'assignatura"),
    ("group", "Grup"),
    ("teacher", "Professor/s (separats per coma si són diversos)"),
    ("weekly_hours", "Durada total (hores, p.ex. 1,5 = 1h 30min)"),
    ("allowed_session_lengths", "Durades de sessió permeses (p.ex. 2+3, opcional)"),
    ("preferred_room", "Aula preferida (opcional)"),
    ("max_session_days", "Màxim de dies en què es pot repartir (mínim 1h per sessió)"),
    ("fixed_day", "Dia fix (opcional)"),
    ("fixed_start", "Hora fixa (opcional, p.ex. 9:00)"),
    ("consecutive_subject", "Consecutiva amb - Assignatura (opcional)"),
    ("consecutive_teacher", "Consecutiva amb - Professor (opcional, per desdoblats)"),
]

ROOM_COLUMNS = [
    ("name", "Nom de l'aula"),
    ("active", "Activa (Sí/No)"),
    ("capacity", "Capacitat"),
]


def _bool_to_text(value: Any) -> str:
    return "Sí" if value else "No"


def _text_to_bool(value: Any) -> bool:
    text = str(value or "").strip().lower()
    return text in ("sí", "si", "s", "yes", "true", "1", "x")


def _slots_to_text(slots: Any) -> str:
    if not slots:
        return ""
    return ", ".join(str(slot) for slot in slots)


def _text_to_slots(value: Any) -> List[str]:
    text = str(value or "").strip()
    if not text:
        return []
    return [part.strip() for part in text.replace("\n", ",").split(",") if part.strip()]


def _text_to_optional_float(value: Any):
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "."))
    except ValueError:
        return None


def _format_hours(value: Any) -> Any:
    if value in (None, ""):
        return ""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return value
    return int(number) if number == int(number) else number


def _lengths_to_text(lengths: Any) -> str:
    if not lengths:
        return ""
    parts = []
    for length in lengths:
        formatted = _format_hours(length)
        parts.append(str(formatted) if formatted != "" else "0")
    return "+".join(parts)


def _text_to_lengths(value: Any) -> List[float]:
    text = str(value or "").strip()
    if not text:
        return []
    lengths = []
    for part in text.split("+"):
        part = part.strip().replace(",", ".")
        if not part:
            continue
        try:
            lengths.append(float(part))
        except ValueError:
            continue
    return lengths


def _consecutive_group_to_text(value: Any) -> tuple:
    """Separa el valor intern ('Assignatura::Professor') en les dues
    columnes llegibles del full de càlcul."""
    text = str(value or "").strip()
    if "::" in text:
        subject, teacher = text.split("::", 1)
        return subject.strip(), teacher.strip()
    return text, ""


def _text_to_consecutive_group(subject: Any, teacher: Any) -> str:
    subject_text = str(subject or "").strip()
    teacher_text = str(teacher or "").strip()
    if not subject_text:
        return ""
    return f"{subject_text}::{teacher_text}" if teacher_text else subject_text


def _write_sheet(workbook: Workbook, title: str, columns, rows: List[Dict[str, Any]], note: str = "") -> None:
    sheet = workbook.create_sheet(title=title)

    start_row = 1
    if note:
        sheet.cell(row=1, column=1, value=note).font = NOTE_FONT
        sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(columns))
        start_row = 2

    for col_index, (_, label) in enumerate(columns, start=1):
        cell = sheet.cell(row=start_row, column=col_index, value=label)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center")

    for row_offset, row in enumerate(rows, start=start_row + 1):
        for col_index, (key, _) in enumerate(columns, start=1):
            sheet.cell(row=row_offset, column=col_index, value=row.get(key, ""))

    for col_index in range(1, len(columns) + 1):
        sheet.column_dimensions[get_column_letter(col_index)].width = 26
    sheet.freeze_panes = sheet.cell(row=start_row + 1, column=1)


def _text_to_optional_int(value: Any):
    if value in (None, ""):
        return None
    try:
        return int(float(str(value).replace(",", ".")))
    except ValueError:
        return None


def _teacher_rows(repo: AcademicDataRepository) -> List[Dict[str, Any]]:
    restrictions = {item["teacher"]: item for item in repo.list_teacher_restrictions()}
    # Grups on cada professor consta com a tutor/a (la dada viu al grup).
    tutor_groups: Dict[str, List[str]] = {}
    for group in repo.list_groups():
        tutor_name = str(group.get("tutor") or "").strip()
        group_name = str(group.get("name") or "").strip()
        if tutor_name and group_name:
            tutor_groups.setdefault(tutor_name.casefold(), []).append(group_name)
    rows = []
    for teacher in repo.list_teachers():
        restriction = restrictions.get(teacher["name"], {})
        rows.append({
            "name": teacher.get("name", ""),
            "active": _bool_to_text(teacher.get("active", True)),
            "dedication_pct": _format_hours(teacher.get("dedication_pct")),
            "dni": teacher.get("dni", ""),
            "center_hours": _format_hours(teacher.get("center_hours")),
            "coordination_name": teacher.get("coordination_name", ""),
            "coordination_hours": _format_hours(teacher.get("coordination_hours")),
            "no_gaps": _bool_to_text(restriction.get("no_gaps")),
            "max_hours_per_day": restriction.get("max_hours_per_day", ""),
            "max_consecutive_hours": restriction.get("max_consecutive_hours", ""),
            "max_days": restriction.get("max_days", ""),
            "preferred_availability": _slots_to_text(restriction.get("preferred_availability")),
            "unavailable_slots": _slots_to_text(restriction.get("unavailable_slots")),
            "tutor_of": ", ".join(tutor_groups.get(str(teacher.get("name") or "").casefold(), [])),
        })
    return rows


def _group_rows(repo: AcademicDataRepository) -> List[Dict[str, Any]]:
    restrictions = {item["group"]: item for item in repo.list_group_restrictions()}
    rows = []
    for group in repo.list_groups():
        restriction = restrictions.get(group["name"], {})
        rows.append({
            "name": group.get("name", ""),
            "active": _bool_to_text(group.get("active", True)),
            "tutor": group.get("tutor", ""),
            "is_split": _bool_to_text(group.get("is_split")),
            "no_gaps": _bool_to_text(restriction.get("no_gaps")),
            "max_hours_per_day": restriction.get("max_hours_per_day", ""),
            "max_consecutive_hours": restriction.get("max_consecutive_hours", ""),
            "max_days": restriction.get("max_days", ""),
            "minimum_daily_hours": restriction.get("minimum_daily_hours", ""),
            "preferred_availability": _slots_to_text(restriction.get("preferred_availability")),
            "unavailable_slots": _slots_to_text(restriction.get("unavailable_slots")),
        })
    return rows


def _subject_rows(repo: AcademicDataRepository) -> List[Dict[str, Any]]:
    rows = []
    for assignment in repo.active_canonical_assignments():
        consecutive_subject, consecutive_teacher = _consecutive_group_to_text(assignment.get("consecutive_group"))
        rows.append({
            "subject": assignment.get("subject", ""),
            "group": assignment.get("group", ""),
            "teacher": assignment.get("teacher", ""),
            "weekly_hours": _format_hours(assignment.get("weekly_hours")),
            "allowed_session_lengths": _lengths_to_text(assignment.get("allowed_session_lengths")),
            "preferred_room": assignment.get("preferred_room", ""),
            "max_session_days": assignment.get("max_session_days", ""),
            "fixed_day": assignment.get("fixed_day", ""),
            "fixed_start": assignment.get("fixed_start", ""),
            "consecutive_subject": consecutive_subject,
            "consecutive_teacher": consecutive_teacher,
        })
    return rows


def _room_rows(repo: AcademicDataRepository) -> List[Dict[str, Any]]:
    return [
        {
            "name": room.get("name", ""),
            "active": _bool_to_text(room.get("active", True)),
            "capacity": room.get("capacity", ""),
        }
        for room in repo.list_rooms()
    ]


def build_workbook(repo: AcademicDataRepository | None, blank: bool) -> BytesIO:
    """Construeix el full de càlcul. Si blank=True, només hi ha les
    capçaleres (per començar de zero); si no, s'omple amb les dades actuals."""
    workbook = Workbook()
    workbook.remove(workbook.active)

    teacher_rows = [] if blank else _teacher_rows(repo)
    group_rows = [] if blank else _group_rows(repo)
    subject_rows = [] if blank else _subject_rows(repo)
    room_rows = [] if blank else _room_rows(repo)

    _write_sheet(
        workbook, "Professors", TEACHER_COLUMNS, teacher_rows,
        note="Dades i restriccions horàries de cada professor. Format d'hora: Dilluns 8:00, Dilluns 8:30... (blocs de mitja hora).",
    )
    _write_sheet(
        workbook, "Grups", GROUP_COLUMNS, group_rows,
        note="Dades i restriccions horàries de cada grup d'alumnes.",
    )
    _write_sheet(
        workbook, "Assignatures", SUBJECT_COLUMNS, subject_rows,
        note="Durada sempre en HORES (decimal, p.ex. 1,5 = 1h30min). Mínim 1 hora per sessió.",
    )
    _write_sheet(
        workbook, "Aules", ROOM_COLUMNS, room_rows,
    )

    buffer = BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


def _read_sheet_rows(workbook, title: str, columns) -> List[Dict[str, Any]]:
    if title not in workbook.sheetnames:
        return []
    sheet = workbook[title]

    header_row_index = None
    header_map: Dict[int, str] = {}
    for row in sheet.iter_rows(min_row=1, max_row=3):
        labels = [str(cell.value or "").strip() for cell in row]
        matches = sum(1 for _, label in columns if label in labels)
        if matches >= max(1, len(columns) // 2):
            header_row_index = row[0].row
            for cell in row:
                for key, label in columns:
                    if str(cell.value or "").strip() == label:
                        header_map[cell.column] = key
            break

    if header_row_index is None:
        return []

    rows = []
    for row in sheet.iter_rows(min_row=header_row_index + 1):
        if all(cell.value in (None, "") for cell in row):
            continue
        record: Dict[str, Any] = {}
        for cell in row:
            key = header_map.get(cell.column)
            if key:
                record[key] = cell.value
        if record:
            rows.append(record)
    return rows


def import_workbook(repo: AcademicDataRepository, file_bytes: bytes) -> Dict[str, int]:
    """Llegeix el full de càlcul unificat i substitueix les dades acadèmiques
    del repositori (professors, grups, assignatures, aules, restriccions)."""
    workbook = load_workbook(BytesIO(file_bytes), data_only=True)

    teacher_rows = _read_sheet_rows(workbook, "Professors", TEACHER_COLUMNS)
    group_rows = _read_sheet_rows(workbook, "Grups", GROUP_COLUMNS)
    subject_rows = _read_sheet_rows(workbook, "Assignatures", SUBJECT_COLUMNS)
    room_rows = _read_sheet_rows(workbook, "Aules", ROOM_COLUMNS)

    for existing in list(repo.active_canonical_assignments()):
        repo.delete_canonical_assignment(existing["id"])
    for existing in list(repo.list_teachers()):
        repo.delete_teacher(existing["name"])
    for existing in list(repo.list_groups()):
        repo.delete_group(existing["name"])
    for existing in list(repo.list_rooms()):
        repo.delete_room(existing["name"])

    teachers_created = 0
    for row in teacher_rows:
        name = str(row.get("name") or "").strip()
        if not name:
            continue
        repo.create_teacher({
            "name": name,
            "active": _text_to_bool(row.get("active")) if row.get("active") not in (None, "") else True,
            "center_hours": _text_to_optional_float(row.get("center_hours")),
            "coordination_name": str(row.get("coordination_name") or "").strip(),
            "coordination_hours": _text_to_optional_float(row.get("coordination_hours")),
            "dedication_pct": parse_dedication_pct(row.get("dedication_pct")),
            "dni": str(row.get("dni") or "").strip().upper(),
        })
        teachers_created += 1
        max_days = _text_to_optional_int(row.get("max_days"))
        if row.get("no_gaps") is not None or row.get("unavailable_slots") or row.get("preferred_availability") or max_days:
            repo.upsert_teacher_restriction({
                "teacher": name,
                "no_gaps": _text_to_bool(row.get("no_gaps")),
                "max_hours_per_day": row.get("max_hours_per_day") or None,
                "max_consecutive_hours": row.get("max_consecutive_hours") or None,
                "max_days": max_days,
                "preferred_availability": _text_to_slots(row.get("preferred_availability")),
                "unavailable_slots": _text_to_slots(row.get("unavailable_slots")),
            })

    groups_created = 0
    for row in group_rows:
        name = str(row.get("name") or "").strip()
        if not name:
            continue
        repo.create_group({
            "name": name,
            "tutor": str(row.get("tutor") or "").strip(),
            "is_split": _text_to_bool(row.get("is_split")),
        })
        groups_created += 1
        group_max_days = _text_to_optional_int(row.get("max_days"))
        if row.get("no_gaps") is not None or row.get("unavailable_slots") or row.get("preferred_availability") or group_max_days:
            repo.upsert_group_restriction({
                "group": name,
                "no_gaps": _text_to_bool(row.get("no_gaps")),
                "max_hours_per_day": row.get("max_hours_per_day") or None,
                "max_consecutive_hours": row.get("max_consecutive_hours") or None,
                "max_days": group_max_days,
                "minimum_daily_hours": _text_to_optional_float(row.get("minimum_daily_hours")),
                "preferred_availability": _text_to_slots(row.get("preferred_availability")),
                "unavailable_slots": _text_to_slots(row.get("unavailable_slots")),
            })

    rooms_created = 0
    for row in room_rows:
        name = str(row.get("name") or "").strip()
        if not name:
            continue
        try:
            capacity = int(float(str(row.get("capacity") or "0").replace(",", ".")))
        except ValueError:
            capacity = 0
        repo.create_room({"name": name, "capacity": max(capacity, 0)})
        rooms_created += 1

    assignments_created = 0
    for row in subject_rows:
        subject = str(row.get("subject") or "").strip()
        group = str(row.get("group") or "").strip()
        teacher = str(row.get("teacher") or "").strip()
        if not subject or not group:
            continue
        try:
            weekly_hours = float(str(row.get("weekly_hours") or "0").replace(",", "."))
        except ValueError:
            weekly_hours = 0.0
        repo.create_canonical_assignment({
            "teacher": teacher,
            "subject": subject,
            "group": group,
            "weekly_hours": weekly_hours,
            "allowed_session_lengths": _text_to_lengths(row.get("allowed_session_lengths")),
            "preferred_room": str(row.get("preferred_room") or "").strip(),
            "max_session_days": row.get("max_session_days") or "",
            "fixed_day": str(row.get("fixed_day") or "").strip(),
            "fixed_start": str(row.get("fixed_start") or "").strip(),
            "consecutive_group": _text_to_consecutive_group(row.get("consecutive_subject"), row.get("consecutive_teacher")),
        })
        assignments_created += 1

    return {
        "teachers": teachers_created,
        "groups": groups_created,
        "rooms": rooms_created,
        "assignments": assignments_created,
    }


@router.get("/spreadsheet/blank")
def download_blank_spreadsheet():
    buffer = build_workbook(None, blank=True)
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="EMAD-model-buit.xlsx"'},
    )


@router.get("/spreadsheet/current")
def download_current_spreadsheet():
    repo = get_academic_data_repo()
    buffer = build_workbook(repo, blank=False)
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="EMAD-dades-actuals.xlsx"'},
    )


@router.post("/spreadsheet/import")
async def import_spreadsheet(file: UploadFile = File(...)):
    repo = get_academic_data_repo()
    file_bytes = await file.read()
    try:
        result = import_workbook(repo, file_bytes)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "ok": True,
        "teachers": result["teachers"],
        "groups": result["groups"],
        "assignments": result["assignments"],
        "rooms": result["rooms"],
    }
