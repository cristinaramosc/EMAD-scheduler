from __future__ import annotations

from typing import Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

try:
    from backend.dependencies import get_academic_data_repo
    from backend.services.contract_hours import contract_hours, parse_dedication_pct
except ModuleNotFoundError:  # pragma: no cover
    from dependencies import get_academic_data_repo
    from services.contract_hours import contract_hours, parse_dedication_pct


router = APIRouter(prefix="/academic-data", tags=["Academic Data"])


def _normalized_name(value: str) -> str:
    return str(value or "").strip().casefold()


def _tutor_groups_by_teacher(repo) -> Dict[str, str]:
    """Retorna, per a cada professor, la llista de grups on consta com a tutor.

    La dada viu al grup (`Dades acadèmiques > Grups > Tutor`); això només la
    resumeix per poder-la mostrar a la fitxa del professor.
    """
    groups_by_teacher: Dict[str, List[str]] = {}
    for group in repo.list_groups():
        tutor_name = str(group.get("tutor") or "").strip()
        group_name = str(group.get("name") or "").strip()
        if not tutor_name or not group_name:
            continue
        groups_by_teacher.setdefault(_normalized_name(tutor_name), []).append(group_name)
    return {key: ", ".join(names) for key, names in groups_by_teacher.items()}


def _merge_teacher_restriction(repo, teacher_name: str, values: Dict[str, object]) -> None:
    """Actualitza només els camps indicats de la restricció del professor,
    conservant la resta (max_days, no_gaps, franges... ja guardades)."""
    existing = next(
        (
            item
            for item in repo.list_teacher_restrictions()
            if _normalized_name(item.get("teacher")) == _normalized_name(teacher_name)
        ),
        {},
    )
    repo.upsert_teacher_restriction({**existing, **values, "teacher": teacher_name})


def _normalized_max_days(value) -> Optional[int]:
    """`Màxim de dies de classe per setmana`: buit o 0 vol dir sense límit."""
    if value in (None, ""):
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


@router.get("/summary")
def academic_data_summary():
    return get_academic_data_repo().summary()


class TeacherDTO(BaseModel):
    name: str
    active: Optional[bool] = True
    unavailable_slots: Optional[List[str]] = []
    center_hours: Optional[float] = None
    coordination_name: Optional[str] = ""
    coordination_hours: Optional[float] = None
    max_days: Optional[int] = None
    dedication_pct: Optional[float] = None  # % de jornada (0-100); 0 l'esborra
    dni: Optional[str] = ""


class TeacherUpdateDTO(BaseModel):
    name: Optional[str] = None
    active: Optional[bool] = None
    unavailable_slots: Optional[List[str]] = None
    center_hours: Optional[float] = None
    coordination_name: Optional[str] = None
    coordination_hours: Optional[float] = None
    max_days: Optional[int] = None
    dedication_pct: Optional[float] = None  # % de jornada (0-100); 0 l'esborra
    dni: Optional[str] = None


class TeacherRestrictionDTO(BaseModel):
    teacher: str
    no_gaps: Optional[bool] = False
    max_days: Optional[int] = None
    max_hours_per_day: Optional[float] = None
    max_consecutive_hours: Optional[float] = None
    preferred_availability: Optional[List[str]] = []
    unavailable_slots: Optional[List[str]] = []
    weekly_meeting_active: Optional[bool] = True
    weekly_coordination_active: Optional[bool] = True


class TeacherRestrictionUpdateDTO(BaseModel):
    teacher: Optional[str] = None
    no_gaps: Optional[bool] = None
    max_days: Optional[int] = None
    max_hours_per_day: Optional[float] = None
    max_consecutive_hours: Optional[float] = None
    preferred_availability: Optional[List[str]] = None
    unavailable_slots: Optional[List[str]] = None
    weekly_meeting_active: Optional[bool] = None
    weekly_coordination_active: Optional[bool] = None


class GroupDTO(BaseModel):
    name: str
    tutor: Optional[str] = ""
    active: Optional[bool] = True
    unavailable_slots: Optional[List[str]] = []
    fixed_slots: Optional[List[str]] = []
    is_split: Optional[bool] = False


class GroupUpdateDTO(BaseModel):
    name: Optional[str] = None
    tutor: Optional[str] = None
    active: Optional[bool] = None
    unavailable_slots: Optional[List[str]] = None
    fixed_slots: Optional[List[str]] = None
    is_split: Optional[bool] = None


class GroupRestrictionDTO(BaseModel):
    group: str
    no_gaps: Optional[bool] = False
    max_hours_per_day: Optional[float] = None
    max_consecutive_hours: Optional[float] = None
    minimum_daily_hours: Optional[float] = None
    max_days: Optional[int] = None
    preferred_availability: Optional[List[str]] = []
    unavailable_slots: Optional[List[str]] = []
    daily_start_time: Optional[str] = ""
    daily_max_end_time: Optional[str] = ""
    daily_windows: Optional[Dict[str, Dict[str, str]]] = {}
    exception_slots: Optional[List[str]] = []
    break_days: Optional[List[str]] = []
    break_slots: Optional[List[str]] = []
    locked: Optional[bool] = False


class GroupRestrictionUpdateDTO(BaseModel):
    group: Optional[str] = None
    no_gaps: Optional[bool] = None
    max_hours_per_day: Optional[float] = None
    max_consecutive_hours: Optional[float] = None
    minimum_daily_hours: Optional[float] = None
    max_days: Optional[int] = None
    preferred_availability: Optional[List[str]] = None
    unavailable_slots: Optional[List[str]] = None
    daily_start_time: Optional[str] = None
    daily_max_end_time: Optional[str] = None
    daily_windows: Optional[Dict[str, Dict[str, str]]] = None
    exception_slots: Optional[List[str]] = None
    break_days: Optional[List[str]] = None
    break_slots: Optional[List[str]] = None
    locked: Optional[bool] = None


class SubjectDTO(BaseModel):
    name: str
    group: Optional[str] = ""
    color: Optional[str] = ""
    allowed_session_lengths: Optional[List[float]] = []
    weekly_hours: Optional[float] = 0


class SubjectUpdateDTO(BaseModel):
    name: Optional[str] = None
    group: Optional[str] = None
    color: Optional[str] = None
    allowed_session_lengths: Optional[List[float]] = None
    weekly_hours: Optional[float] = None


class RoomDTO(BaseModel):
    name: str
    capacity: Optional[int] = Field(default=0, ge=0)
    unavailable_slots: Optional[List[str]] = []


class RoomUpdateDTO(BaseModel):
    name: Optional[str] = None
    capacity: Optional[int] = Field(default=None, ge=0)
    unavailable_slots: Optional[List[str]] = None


class AssignmentDTO(BaseModel):
    teacher: str
    subject: str
    group: str
    weekly_hours: float
    allowed_session_lengths: Optional[List[float]] = []
    preferred_room: Optional[str] = ""
    notes: Optional[str] = ""
    fixed_day: Optional[str] = ""
    fixed_start: Optional[str] = ""
    max_session_days: Optional[str] = ""
    consecutive_group: Optional[str] = ""


class AssignmentUpdateDTO(BaseModel):
    teacher: Optional[str] = None
    subject: Optional[str] = None
    group: Optional[str] = None
    weekly_hours: Optional[float] = None
    allowed_session_lengths: Optional[List[float]] = None
    preferred_room: Optional[str] = None
    notes: Optional[str] = None
    fixed_day: Optional[str] = None
    fixed_start: Optional[str] = None
    max_session_days: Optional[str] = None
    consecutive_group: Optional[str] = None


def _clean_dedication_pct(value):
    """Valida el % de jornada: None/0 = sense percentatge; 0-100 altrament."""
    if value is None or float(value) == 0:
        return None
    pct = parse_dedication_pct(value)
    if pct is None:
        raise HTTPException(status_code=400, detail="dedication_pct_invalid")
    return pct


def _clean_dni(value) -> str:
    return str(value or "").strip().upper()


@router.get("/teachers")
def list_teachers():
    repo = get_academic_data_repo()
    teachers = repo.list_teachers()
    restrictions = {r["teacher"]: r for r in repo.list_teacher_restrictions()}
    tutor_groups = _tutor_groups_by_teacher(repo)
    for teacher in teachers:
        teacher.update(restrictions.get(teacher["name"], {}))
        # `tutor_of` = grups on aquest professor consta com a tutor/a (vegeu
        # `_tutor_groups_by_teacher`): informació de la fitxa, no un camp propi.
        teacher["tutor_of"] = tutor_groups.get(_normalized_name(teacher["name"]), "")
        # Hores de contracte derivades del % de jornada (només lectura).
        teacher["contract_hours"] = contract_hours(teacher.get("dedication_pct"))
    return teachers


@router.post("/teachers")
def create_teacher(payload: TeacherDTO):
    repo = get_academic_data_repo()
    try:
        record = payload.model_dump()
        active = record.pop("active", True)
        max_days = _normalized_max_days(record.pop("max_days", None))
        record["dedication_pct"] = _clean_dedication_pct(record.get("dedication_pct"))
        record["dni"] = _clean_dni(record.get("dni"))
        repo.create_teacher(record)
        if not active:
            repo.delete_teacher(record["name"])
        if payload.unavailable_slots or max_days:
            repo.upsert_teacher_restriction({
                "teacher": payload.name,
                "max_days": max_days,
                "unavailable_slots": payload.unavailable_slots or [],
            })
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.patch("/teachers/{name}")
def update_teacher(name: str, payload: TeacherUpdateDTO):
    repo = get_academic_data_repo()
    current = next((t for t in repo.list_teachers() if t["name"] == name), None)
    if current is None:
        raise HTTPException(status_code=404, detail="teacher_not_found")
    if payload.active is False:
        repo.delete_teacher(name)
        return {"ok": True}
    values = payload.model_dump()
    # `max_days` no és un camp del professor sinó de la seva restricció, i
    # `unavailable_slots` s'hi desa igualment: tots dos es tracten a part
    # perquè `update_teacher` no els pot escriure.
    max_days = _normalized_max_days(values.pop("max_days", None))
    updated = {**current, **{k: v for k, v in values.items() if v is not None and k != "active"}}
    if payload.dedication_pct is not None:
        updated["dedication_pct"] = _clean_dedication_pct(payload.dedication_pct)
    if payload.dni is not None:
        updated["dni"] = _clean_dni(payload.dni)
    try:
        repo.update_teacher(name, updated)
        if payload.unavailable_slots is not None:
            _merge_teacher_restriction(repo, updated["name"], {"unavailable_slots": payload.unavailable_slots})
        if payload.max_days is not None:
            _merge_teacher_restriction(repo, updated["name"], {"max_days": max_days})
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.delete("/teachers/{name}")
def delete_teacher(name: str):
    repo = get_academic_data_repo()
    try:
        repo.delete_teacher(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.get("/teachers/{name}/restrictions")
def get_teacher_restrictions(name: str):
    repo = get_academic_data_repo()
    restriction = next((item for item in repo.list_teacher_restrictions() if item.get("teacher") == name), None)

    if restriction is None:
        raise HTTPException(status_code=404, detail="teacher_restrictions_not_found")

    merged = dict(restriction)
    merged.setdefault("weekly_meeting_active", True)
    merged.setdefault("weekly_coordination_active", True)
    return merged


@router.patch("/teachers/{name}/restrictions")
def update_teacher_restrictions(name: str, payload: TeacherRestrictionUpdateDTO):
    repo = get_academic_data_repo()
    current = next((item for item in repo.list_teachers() if item.get("name") == name), None)
    if current is None:
        raise HTTPException(status_code=404, detail="teacher_not_found")

    existing_restriction = next((item for item in repo.list_teacher_restrictions() if item.get("teacher") == name), None)
    existing_weekly_meeting_active = (existing_restriction or {}).get("weekly_meeting_active", True)
    existing_weekly_coordination_active = (existing_restriction or {}).get("weekly_coordination_active", True)

    record = {
        "teacher": payload.teacher or name,
        "no_gaps": payload.no_gaps if payload.no_gaps is not None else False,
        "max_days": payload.max_days if payload.max_days is not None else (existing_restriction or {}).get("max_days"),
        "max_hours_per_day": payload.max_hours_per_day,
        "max_consecutive_hours": payload.max_consecutive_hours,
        "preferred_availability": payload.preferred_availability if payload.preferred_availability is not None else [],
        "unavailable_slots": payload.unavailable_slots if payload.unavailable_slots is not None else [],
        "weekly_meeting_active": payload.weekly_meeting_active if payload.weekly_meeting_active is not None else existing_weekly_meeting_active,
        "weekly_coordination_active": payload.weekly_coordination_active if payload.weekly_coordination_active is not None else existing_weekly_coordination_active,
    }
    repo.upsert_teacher_restriction(record)
    return {"ok": True}


@router.get("/groups")
def list_groups():
    repo = get_academic_data_repo()
    groups = repo.list_groups()
    restrictions = {_normalized_name(r.get("group")): r for r in repo.list_group_restrictions()}
    for group in groups:
        group.update(restrictions.get(_normalized_name(group.get("name")), {}))
    return groups


@router.post("/groups")
def create_group(payload: GroupDTO):
    repo = get_academic_data_repo()
    try:
        record = payload.model_dump()
        active = record.pop("active", True)
        repo.create_group(record)
        if not active:
            repo.delete_group(record["name"])
        if payload.unavailable_slots or payload.fixed_slots:
            repo.upsert_group_restriction({
                "group": payload.name,
                "unavailable_slots": payload.unavailable_slots or [],
                "fixed_slots": payload.fixed_slots or [],
            })
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.patch("/groups/{name}")
def update_group(name: str, payload: GroupUpdateDTO):
    repo = get_academic_data_repo()
    current = next((g for g in repo.list_groups() if g["name"] == name), None)
    if current is None:
        raise HTTPException(status_code=404, detail="group_not_found")
    if payload.active is False:
        repo.delete_group(name)
        return {"ok": True}
    updated = {**current, **{k: v for k, v in payload.model_dump().items() if v is not None and k != "active"}}
    try:
        repo.update_group(name, updated)
        if payload.unavailable_slots is not None or payload.fixed_slots is not None:
            repo.upsert_group_restriction({
                "group": updated["name"],
                "unavailable_slots": updated.get("unavailable_slots", []),
                "fixed_slots": updated.get("fixed_slots", []),
            })
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.delete("/groups/{name}")
def delete_group(name: str):
    repo = get_academic_data_repo()
    try:
        repo.delete_group(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.get("/groups/{name}/restrictions")
def get_group_restrictions(name: str):
    repo = get_academic_data_repo()
    restriction = next(
        (item for item in repo.list_group_restrictions() if _normalized_name(item.get("group")) == _normalized_name(name)),
        None,
    )

    if restriction is None:
        raise HTTPException(status_code=404, detail="group_restrictions_not_found")

    return dict(restriction)


@router.patch("/groups/{name}/restrictions")
def update_group_restrictions(name: str, payload: GroupRestrictionUpdateDTO):
    repo = get_academic_data_repo()
    current = next(
        (item for item in repo.list_groups() if _normalized_name(item.get("name")) == _normalized_name(name)),
        None,
    )
    if current is None:
        raise HTTPException(status_code=404, detail="group_not_found")

    existing_restriction = next(
        (item for item in repo.list_group_restrictions() if _normalized_name(item.get("group")) == _normalized_name(name)),
        {},
    )

    record = {
        "group": payload.group or name,
        "no_gaps": payload.no_gaps if payload.no_gaps is not None else False,
        "max_hours_per_day": payload.max_hours_per_day,
        "max_consecutive_hours": payload.max_consecutive_hours,
        "minimum_daily_hours": payload.minimum_daily_hours if payload.minimum_daily_hours is not None else existing_restriction.get("minimum_daily_hours"),
        "max_days": payload.max_days if payload.max_days is not None else existing_restriction.get("max_days"),
        "preferred_availability": payload.preferred_availability if payload.preferred_availability is not None else existing_restriction.get("preferred_availability", []),
        "unavailable_slots": payload.unavailable_slots if payload.unavailable_slots is not None else existing_restriction.get("unavailable_slots", []),
        "fixed_slots": existing_restriction.get("fixed_slots", []),
        "daily_start_time": payload.daily_start_time if payload.daily_start_time is not None else existing_restriction.get("daily_start_time", ""),
        "daily_max_end_time": payload.daily_max_end_time if payload.daily_max_end_time is not None else existing_restriction.get("daily_max_end_time", ""),
        "daily_windows": payload.daily_windows if payload.daily_windows is not None else existing_restriction.get("daily_windows", {}),
        "exception_slots": payload.exception_slots if payload.exception_slots is not None else existing_restriction.get("exception_slots", []),
        "break_days": payload.break_days if payload.break_days is not None else existing_restriction.get("break_days", []),
        "break_slots": payload.break_slots if payload.break_slots is not None else existing_restriction.get("break_slots", []),
        "locked": payload.locked if payload.locked is not None else existing_restriction.get("locked", False),
    }
    repo.upsert_group_restriction(record)
    return {"ok": True}


@router.get("/subjects")
def list_subjects():
    repo = get_academic_data_repo()
    subjects = list(repo.list_subjects())
    known_names = {_normalized_name(subject.get("name")) for subject in subjects}
    for assignment in repo.active_canonical_assignments():
        name = str(assignment.get("subject") or "").strip()
        if not name or _normalized_name(name) in known_names:
            continue
        subjects.append(
            {
                "name": name,
                "group": assignment.get("group", ""),
                "weekly_hours": assignment.get("weekly_hours", 0),
                "allowed_session_lengths": assignment.get("allowed_session_lengths", []),
            }
        )
        known_names.add(_normalized_name(name))
    return subjects


@router.post("/subjects")
def create_subject(payload: SubjectDTO):
    repo = get_academic_data_repo()
    try:
        repo.create_subject(payload.model_dump())
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.patch("/subjects/{name}")
def update_subject(name: str, payload: SubjectUpdateDTO):
    repo = get_academic_data_repo()
    current = next((s for s in repo.list_subjects() if s["name"] == name), None)
    if current is None:
        raise HTTPException(status_code=404, detail="subject_not_found")
    updated = {**current, **{k: v for k, v in payload.model_dump().items() if v is not None}}
    try:
        repo.update_subject(name, updated)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.delete("/subjects/{name}")
def delete_subject(name: str):
    repo = get_academic_data_repo()
    try:
        repo.delete_subject(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.get("/rooms")
def list_rooms():
    return get_academic_data_repo().list_rooms()


@router.post("/rooms")
def create_room(payload: RoomDTO):
    repo = get_academic_data_repo()
    try:
        repo.create_room(payload.model_dump())
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.patch("/rooms/{name}")
def update_room(name: str, payload: RoomUpdateDTO):
    repo = get_academic_data_repo()
    current = next((r for r in repo.list_rooms() if r["name"] == name), None)
    if current is None:
        raise HTTPException(status_code=404, detail="room_not_found")
    updated = {**current, **{k: v for k, v in payload.model_dump().items() if v is not None}}
    try:
        repo.update_room(name, updated)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.delete("/rooms/{name}")
def delete_room(name: str):
    repo = get_academic_data_repo()
    try:
        repo.delete_room(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.get("/assignments")
def list_assignments():
    return get_academic_data_repo().active_canonical_assignments()


@router.post("/assignments")
def create_assignment(payload: AssignmentDTO):
    repo = get_academic_data_repo()
    subject = next((s for s in list_subjects() if _normalized_name(s.get("name")) == _normalized_name(payload.subject)), None)
    if subject is None:
        try:
            repo.create_subject({
                "name": payload.subject.strip(),
                "allowed_session_lengths": [],
                "weekly_hours": payload.weekly_hours,
            })
        except KeyError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        subject = {"name": payload.subject.strip(), "allowed_session_lengths": []}
    try:
        record = payload.model_dump()
        record["allowed_session_lengths"] = subject.get("allowed_session_lengths", [])
        assignment_id = repo.create_canonical_assignment(record)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "id": assignment_id}


@router.patch("/assignments/{assignment_id}")
def update_assignment(assignment_id: str, payload: AssignmentUpdateDTO):
    repo = get_academic_data_repo()
    current = next((a for a in repo.active_canonical_assignments() if a["id"] == assignment_id), None)
    if current is None:
        raise HTTPException(status_code=404, detail="assignment_not_found")
    updated = {**current, **{k: v for k, v in payload.model_dump().items() if v is not None}}
    subject = next((s for s in list_subjects() if _normalized_name(s.get("name")) == _normalized_name(updated["subject"])), None)
    if subject:
        updated["allowed_session_lengths"] = subject.get("allowed_session_lengths", [])
    try:
        repo.update_canonical_assignment(assignment_id, updated)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}


@router.post("/assignments/{assignment_id}/duplicate")
def duplicate_assignment(assignment_id: str):
    repo = get_academic_data_repo()
    try:
        new_id = repo.duplicate_canonical_assignment(assignment_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="assignment_not_found")
    return {"ok": True, "id": new_id}


@router.delete("/assignments/{assignment_id}")
def delete_assignment(assignment_id: str):
    repo = get_academic_data_repo()
    repo.delete_canonical_assignment(assignment_id)
    return {"ok": True}


class MergeQuartersDTO(BaseModel):
    first_id: str
    second_id: str


@router.post("/assignments/merge-quarters")
def merge_quarter_assignments(payload: MergeQuartersDTO):
    """Compacta dues assignacions (p.ex. dues d'1 hora) en una de sola de 2
    hores que comparteix la mateixa franja tot l'any (1Q per a una, 2Q per
    a l'altra), com 'Foto 1Q + Anglès 2Q'."""
    repo = get_academic_data_repo()
    try:
        new_id = repo.merge_quarter_assignments(payload.first_id, payload.second_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="assignment_not_found")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "id": new_id}


@router.post("/assignments/{assignment_id}/split")
def split_merged_assignment(assignment_id: str):
    """Desfà una assignació compactada, recuperant les dues originals per separat."""
    repo = get_academic_data_repo()
    try:
        new_ids = repo.split_merged_assignment(assignment_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="assignment_not_found")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "ids": new_ids}
